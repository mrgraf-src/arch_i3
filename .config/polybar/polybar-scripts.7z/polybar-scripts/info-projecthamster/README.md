# Script: info-projecthamster

This script displays Hamster Time Tracker information.

![info-projecthamster](screenshots/1.png)


## Module

```ini
[module/info-projecthamster]
type = custom/script
exec = ~/polybar-scripts/info-projecthamster.sh
interval = 5
```
