#!/bin/sh

echo "# $(curl -4 -sf ifconfig.co)"
