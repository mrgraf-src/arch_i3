# Script: info-hexdate

Print the current date in a hex format.

![info-hexdate](screenshots/1.png)


## Module

```ini
[module/info-hexdate]
type = custom/script
exec = ~/polybar-scripts/info-hexdate.sh
interval = 60
```
